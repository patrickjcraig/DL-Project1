# DL-Project1
DL-Proj1

## Relevant Links 
[MNIST](https://yann.lecun.com/exdb/mnist/)

[Deep Learning for Classical Japanese Literature](https://arxiv.org/pdf/1812.01718)

[Best Performing Model Paper on KMNIST](https://github.com/vikasverma1077/manifold_mixup)

[Resenet-1k](https://github.com/KaimingHe/resnet-1k-layers)

[Meta Beyond EMpirical Risk Minimization](https://github.com/facebookresearch/mixup-cifar10)

[Tensorflow Transforms (TFT) ](https://www.tensorflow.org/tfx/tutorials/transform/simple)

[BVAE_TF](https://github.com/alecGraves/BVAE-tf)
